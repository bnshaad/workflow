# Permission Matrix

## Admin
- Manage business
- Manage team
- Create jobs
- Assign workers
- View audit logs
- Configure settings

## Manager
- Create and assign jobs
- Manage team
- View operational dashboards
- Use AI recommendations

## Employee
- View assigned jobs
- Update job status
- Upload work proof
- Report issues